###################################
Source of this project: https://www.udemy.com/course/the-complete-javascript-course/
###################################